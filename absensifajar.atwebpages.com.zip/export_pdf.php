<?php
// 1. Koneksi ke Database
$host = "fdb1034.awardspace.net";
$user = "4757531_absensi";
$pass = "Fajar221!";
$db   = "4757531_absensi";

$conn = mysqli_connect($host, $user, $pass, $db);

// 2. Ambil data dari URL
$email = isset($_GET['email']) ? $_GET['email'] : '';
$nama  = isset($_GET['nama']) ? $_GET['nama'] : 'Mahasiswa';

// 3. 🔥 HEADER SAKTI: Memaksa Browser Download sebagai file Excel (.xls)
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Rekap_Absensi_" . $nama . ".xls");
header("Pragma: no-cache");
header("Expires: 0");

// 4. Query ambil data absen
$sql = "SELECT a.* FROM tb_absensi a 
        JOIN users u ON a.user_id = u.id 
        WHERE u.email = '$email' 
        ORDER BY a.tanggal DESC, a.jam DESC";
$result = mysqli_query($conn, $sql);

// 5. Tampilan Tabel (Otomatis jadi tabel Excel pas dibuka)
?>
<table border="1">
    <thead>
        <tr>
            <th colspan="4" style="background-color: #f2f2f2;">LAPORAN KEHADIRAN MAHASISWA</th>
        </tr>
        <tr>
            <th colspan="4">Nama: <?php echo $nama; ?> (<?php echo $email; ?>)</th>
        </tr>
        <tr style="background-color: #2c3e50; color: white;">
            <th>Tanggal</th>
            <th>Jam</th>
            <th>Status</th>
            <th>Lokasi (Lat, Lng)</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['tanggal'] . "</td>";
                echo "<td>" . $row['jam'] . "</td>";
                echo "<td>" . $row['status'] . "</td>";
                echo "<td>" . $row['lat'] . "," . $row['lng'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4' align='center'>Belum ada data absensi</td></tr>";
        }
        ?>
    </tbody>
</table>
<?php
mysqli_close($conn);
?>