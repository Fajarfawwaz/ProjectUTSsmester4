<?php
header("Content-Type: application/json");
$host = "fdb1034.awardspace.net";
$user = "4757531_absensi";
$pass = "Fajar221!";
$db   = "4757531_absensi";

$conn = mysqli_connect($host, $user, $pass, $db);

$email = $_GET['email']; // Ambil email dari klik di Android

$sql = "SELECT a.* FROM tb_absensi a 
        JOIN users u ON a.user_id = u.id 
        WHERE u.email = '$email' 
        ORDER BY a.tanggal DESC, a.jam DESC";

$result = mysqli_query($conn, $sql);
$data = array();
while($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}
echo json_encode($data);
mysqli_close($conn);
?>
