<?php
// 1. Koneksi ke Database
$host = "fdb1034.awardspace.net";
$user = "4757531_absensi";
$pass = "Fajar221!";
$db   = "4757531_absensi";

$conn = mysqli_connect($host, $user, $pass, $db);

// 2. 🔥 HEADER SAKTI: Memaksa Browser Download sebagai file Excel (.xls)
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=LAPORAN_ABSENSI_GLOBAL_UPB.xls");
header("Pragma: no-cache");
header("Expires: 0");

// 3. Query ambil SEMUA data absen dari SEMUA mahasiswa
$sql = "SELECT u.nama, u.email, a.tanggal, a.jam, a.status, a.lat, a.lng 
        FROM tb_absensi a 
        JOIN users u ON a.user_id = u.id 
        ORDER BY a.tanggal DESC, a.jam DESC";
$result = mysqli_query($conn, $sql);

// 4. Tampilan Tabel Excel
?>
<table border="1">
    <thead>
        <tr>
            <th colspan="6" style="background-color: #1976D2; color: white; height: 30px;">
                LAPORAN KESELURUHAN ABSENSI MAHASISWA - UNIVERSITAS PELITA BANGSA
            </th>
        </tr>
        <tr style="background-color: #f2f2f2; font-weight: bold;">
            <th>Nama Mahasiswa</th>
            <th>Email</th>
            <th>Tanggal</th>
            <th>Jam</th>
            <th>Status</th>
            <th>Lokasi (Lat, Lng)</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['nama'] . "</td>";
                echo "<td>" . $row['email'] . "</td>";
                echo "<td>" . $row['tanggal'] . "</td>";
                echo "<td>" . $row['jam'] . "</td>";
                echo "<td>" . $row['status'] . "</td>";
                echo "<td>" . $row['lat'] . "," . $row['lng'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='6' align='center'>Belum ada data absensi masuk</td></tr>";
        }
        ?>
    </tbody>
</table>
<?php
mysqli_close($conn);
?>