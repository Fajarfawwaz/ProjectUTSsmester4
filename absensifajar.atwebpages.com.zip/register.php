<?php
header('Content-Type: application/json');

$host = "fdb1034.awardspace.net";
$user = "4757531_absensi";
$pass = "Fajar221!";
$db   = "4757531_absensi";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    echo json_encode(["status" => "error", "message" => "Koneksi Gagal"]);
    exit();
}

$nama = $_POST['nama'];
$email = $_POST['email'];
$password = $_POST['password'];

// Cek apakah email sudah ada
$cek = mysqli_query($conn, "SELECT email FROM users WHERE email='$email'");
if (mysqli_num_rows($cek) > 0) {
    echo "EMAIL_SUDAH_ADA";
} else {
    // Masukkan ke database online (Role otomatis 0 / Mahasiswa)
    $sql = "INSERT INTO users (nama, email, password, role, embedding, no_telp, alamat, tgl_lahir) 
            VALUES ('$nama', '$email', '$password', 0, '', '', '', '')";

    if (mysqli_query($conn, $sql)) {
        echo "OK_SUKSES";
    } else {
        echo "GAGAL_SIMPAN_CLOUD";
    }
}

mysqli_close($conn);
?>