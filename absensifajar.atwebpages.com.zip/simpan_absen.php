<?php
// 1. Header untuk memastikan komunikasi lancar
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Cache-Control: no-cache, no-store, must-revalidate");

// 2. Pengaturan Database AwardSpace
$host = "fdb1034.awardspace.net";
$user = "4757531_absensi";
$pass = "Fajar221!";
$db   = "4757531_absensi";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    echo json_encode(["error" => "Koneksi Gagal: " . mysqli_connect_error()]);
    exit();
}

// 3. Ambil data dengan proteksi trim (hapus spasi tersembunyi)
$email   = isset($_POST['email'])   ? trim($_POST['email'])   : null;
$tanggal = isset($_POST['tanggal']) ? trim($_POST['tanggal']) : date('Y-m-d');
$jam     = isset($_POST['jam'])     ? trim($_POST['jam'])     : date('H:i:s');
$status  = isset($_POST['status'])  ? trim($_POST['status'])  : 'Hadir';
$lat     = isset($_POST['lat'])     ? trim($_POST['lat'])     : '0.0';
$lng     = isset($_POST['lng'])     ? trim($_POST['lng'])     : '0.0';

if (empty($email)) {
    echo "ERROR: EMAIL_KOSONG";
    exit();
}

// 4. Cari ID user berdasarkan Email
// Pakai mysqli_real_escape_string biar aman dari karakter aneh
$safeEmail = mysqli_real_escape_string($conn, $email);
$searchUser = mysqli_query($conn, "SELECT id FROM users WHERE email = '$safeEmail'");
$userRow = mysqli_fetch_assoc($searchUser);

if ($userRow) {
    $userIdServer = $userRow['id'];
    
    // 5. Query Simpan - TANPA LIMIT
    // Pastikan di database lo, kolom 'id' itu PRIMARY KEY dan AUTO_INCREMENT
    $sql = "INSERT INTO tb_absensi (user_id, tanggal, jam, status, lat, lng) 
            VALUES ('$userIdServer', '$tanggal', '$jam', '$status', '$lat', '$lng')";
    
    if (mysqli_query($conn, $sql)) {
        // Balasan ini yang ditunggu Android (Retrofit)
        echo "OK_SUKSES";
    } else {
        // Jika gagal insert (misal primary key duplikat atau kolom full)
        echo "SQL_ERROR: " . mysqli_error($conn);
    }
} else {
    echo "ERROR: USER_TIDAK_ADA_DI_CLOUD";
}

mysqli_close($conn);
?>