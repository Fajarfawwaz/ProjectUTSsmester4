<?php
header('Content-Type: application/json');
$host = "fdb1034.awardspace.net";
$user = "4757531_absensi";
$pass = "Fajar221!";
$db   = "4757531_absensi";

$conn = mysqli_connect($host, $user, $pass, $db);

// Ambil 5 data terbaru, urutkan berdasarkan ID paling besar (terbaru)
$sql = "SELECT a.*, u.nama 
        FROM tb_absensi a 
        JOIN users u ON a.user_id = u.id 
        ORDER BY a.id DESC LIMIT 5";

$result = mysqli_query($conn, $sql);
$data = array();

while($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

echo json_encode($data);
mysqli_close($conn);
?>