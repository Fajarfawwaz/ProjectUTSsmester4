<?php
// 🔥 1. Matikan semua laporan error biar gak nampil di layar dan ngerusak download
error_reporting(0);
ini_set('display_errors', 0);

// 2. Koneksi ke Database
$host = "fdb1034.awardspace.net";
$user = "4757531_absensi";
$pass = "Fajar221!";
$db   = "4757531_absensi";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi Gagal");
}

// 3. Ambil semua tabel
$tables = array();
$result = mysqli_query($conn, "SHOW TABLES");
while($row = mysqli_fetch_row($result)) {
    $tables[] = $row[0];
}

$return = "-- Backup Database Absensi Fajar\n";
$return .= "-- Waktu: " . date('Y-m-d H:i:s') . "\n\n";

foreach($tables as $table) {
    $result = mysqli_query($conn, "SELECT * FROM $table");
    $num_fields = mysqli_num_fields($result);

    $return .= "DROP TABLE IF EXISTS $table;";
    $row2 = mysqli_fetch_row(mysqli_query($conn, "SHOW CREATE TABLE $table"));
    $return .= "\n\n" . $row2[1] . ";\n\n";

    while($row = mysqli_fetch_row($result)) {
        $return .= "INSERT INTO $table VALUES(";
        for($j=0; $num_fields > $j; $j++) {
            $row[$j] = addslashes($row[$j]);
            if (isset($row[$j])) { $return .= '"'.$row[$j].'"' ; } else { $return .= '""'; }
            if ($j<($num_fields-1)) { $return .= ','; }
        }
        $return .= ");\n";
    }
    $return .= "\n\n\n";
}

// 🔥 4. JURUS SAKTI: Bersihkan buffer biar gak ada karakter sampah yang nyelip
ob_get_clean();

// 5. 🔥 HEADER PAKSA DOWNLOAD
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header("Content-Transfer-Encoding: Binary");
header("Content-disposition: attachment; filename=\"Backup_Absensi_".date('Y-m-d').".sql\"");
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');

// Keluarkan isi database
echo $return;

mysqli_close($conn);
exit;
?>