<?php
header('Content-Type: application/json');
$host = "fdb1034.awardspace.net";
$user = "4757531_absensi";
$pass = "Fajar221!";
$db   = "4757531_absensi";

$conn = mysqli_connect($host, $user, $pass, $db);

// Ambil tanggal hari ini
$today = date('Y-m-d');

// 1. Hitung Hadir Hari Ini
$qHadir = mysqli_query($conn, "SELECT COUNT(*) as total FROM tb_absensi WHERE tanggal = '$today' AND status = 'Hadir'");
$hadir = mysqli_fetch_assoc($qHadir)['total'];

// 2. Hitung Terlambat Hari Ini
$qTelat = mysqli_query($conn, "SELECT COUNT(*) as total FROM tb_absensi WHERE tanggal = '$today' AND status = 'Terlambat'");
$telat = mysqli_fetch_assoc($qTelat)['total'];

// 3. Hitung Total Mahasiswa Terdaftar
$qMhs = mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE role = 0");
$totalMhs = mysqli_fetch_assoc($qMhs)['total'];

echo json_encode([
    "hadir" => (int)$hadir,
    "telat" => (int)$telat,
    "total_mhs" => (int)$totalMhs
]);

mysqli_close($conn);
?>