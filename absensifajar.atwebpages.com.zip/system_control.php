<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");

// 1. Koneksi ke Database
$host = "fdb1034.awardspace.net";
$user = "4757531_absensi";
$pass = "Fajar221!";
$db   = "4757531_absensi";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    echo json_encode(["status" => "error", "message" => "Koneksi Gagal"]);
    exit();
}

// Ambil aksi dari Android (get_stats, update_config, atau reset_absensi)
$action = isset($_POST['action']) ? $_POST['action'] : 'get_stats';

if ($action == 'get_stats') {
    // A. Hitung Total Mahasiswa
    $qUser = mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE role = 0");
    $totalMhs = mysqli_fetch_assoc($qUser)['total'];

    // B. Hitung Total Seluruh Rekaman Absensi
    $qAbsen = mysqli_query($conn, "SELECT COUNT(*) as total FROM tb_absensi");
    $totalAbsen = mysqli_fetch_assoc($qAbsen)['total'];

    // C. Ambil Data Konfigurasi dari tabel settings
    $qConfig = mysqli_query($conn, "SELECT * FROM settings WHERE id = 1");
    $conf = mysqli_fetch_assoc($qConfig);

    // Jika tabel settings kosong, gunakan default agar tidak error di Android
    $radius = ($conf && isset($conf['radius'])) ? $conf['radius'] . " Meter" : "150 Meter";
    $jam = ($conf && isset($conf['jam_masuk'])) ? $conf['jam_masuk'] . " WIB" : "09:00 WIB";

    echo json_encode([
        "status" => "success",
        "total_mahasiswa" => (string)$totalMhs,
        "total_absensi" => (string)$totalAbsen,
        "radius_saat_ini" => $radius,
        "jam_masuk" => $jam,
        "koordinat_upb" => "-6.3245, 107.1687",
        "server_status" => "ONLINE"
    ]);
} 

else if ($action == 'update_config') {
    // 🔥 FITUR OBENG: Simpan perubahan dari Admin ke database
    $newRadius = isset($_POST['radius']) ? $_POST['radius'] : 150;
    $newJam    = isset($_POST['jam']) ? $_POST['jam'] : '09:00:00';

    $sql = "UPDATE settings SET radius='$newRadius', jam_masuk='$newJam' WHERE id=1";
    
    if (mysqli_query($conn, $sql)) {
        echo json_encode(["status" => "OK_UPDATE"]);
    } else {
        echo json_encode(["status" => "ERROR_UPDATE", "msg" => mysqli_error($conn)]);
    }
}

else if ($action == 'reset_absensi') {
    // 🔥 MAINTENANCE: Kosongkan riwayat absen
    if (mysqli_query($conn, "TRUNCATE TABLE tb_absensi")) {
        echo json_encode(["status" => "OK_RESET"]);
    } else {
        echo json_encode(["status" => "ERROR_RESET"]);
    }
}

mysqli_close($conn);
?>