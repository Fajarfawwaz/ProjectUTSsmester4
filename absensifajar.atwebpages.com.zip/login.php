<?php
header('Content-Type: application/json');

// 1. Pengaturan Database AwardSpace
$host = "fdb1034.awardspace.net";
$user = "4757531_absensi";
$pass = "Fajar221!";
$db   = "4757531_absensi";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    echo json_encode(["status" => "error", "message" => "Koneksi Database Gagal"]);
    exit();
}

// 2. Ambil data dari Android
$email = isset($_POST['email']) ? $_POST['email'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

// 3. Query cari user - Sekarang ambil juga kolom 'embedding'
$sql = "SELECT nama, role, embedding FROM users WHERE email='$email' AND password='$password'";
$result = mysqli_query($conn, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    
    // 🔥 Kirim data lengkap termasuk data wajah (embedding)
    // Supaya Android bisa simpan kembali ke SQLite lokal otomatis
    echo json_encode([
        "status" => "OK_SUKSES",
        "nama" => $row['nama'],
        "role" => (int)$row['role'],
        "embedding" => $row['embedding'] // Data wajah yang tersimpan di Cloud
    ]);
} else {
    // Jika email atau password salah
    echo json_encode([
        "status" => "LOGIN_GAGAL"
    ]);
}

mysqli_close($conn);
?>