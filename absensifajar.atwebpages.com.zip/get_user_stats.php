<?php
header('Content-Type: application/json');
$host = "fdb1034.awardspace.net";
$user = "4757531_absensi";
$pass = "Fajar221!";
$db   = "4757531_absensi";

$conn = mysqli_connect($host, $user, $pass, $db);
$email = $_GET['email'];

// Cari ID server berdasarkan email
$resUser = mysqli_query($conn, "SELECT id FROM users WHERE email = '$email'");
$userRow = mysqli_fetch_assoc($resUser);

if ($userRow) {
    $uid = $userRow['id'];
    
    // Hitung Hadir, Telat, Izin khusus user ini
    $h = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as t FROM tb_absensi WHERE user_id=$uid AND status='Hadir'"))['t'];
    $t = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as t FROM tb_absensi WHERE user_id=$uid AND status='Terlambat'"))['t'];
    $i = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as t FROM tb_absensi WHERE user_id=$uid AND (status='Izin' OR status='Sakit')"))['t'];

    echo json_encode([
        "hadir" => (int)$h,
        "telat" => (int)$t,
        "izin" => (int)$i
    ]);
} else {
    echo json_encode(["hadir" => 0, "telat" => 0, "izin" => 0]);
}
mysqli_close($conn);
?>