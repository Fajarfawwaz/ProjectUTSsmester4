<?php
$host = "fdb1034.awardspace.net";$user = "4757531_absensi";
$pass = "Fajar221!";
$db   = "4757531_absensi";
$conn = mysqli_connect($host, $user, $pass, $db);

$email = $_POST['email'];
$embedding = $_POST['embedding'];

$sql = "UPDATE users SET embedding = '$embedding' WHERE email = '$email'";
if(mysqli_query($conn, $sql)){
    echo "OK";
} else {
    echo "ERROR";
}
mysqli_close($conn);
?>