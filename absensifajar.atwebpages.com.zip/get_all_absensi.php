<?php
header("Access-Control-Allow-Origin: *");

// 1. Koneksi Database
$host = "fdb1034.awardspace.net";
$user = "4757531_absensi";
$pass = "Fajar221!";
$db   = "4757531_absensi";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi Gagal");
}

// 2. Query Rekapitulasi
$sql = "SELECT 
            u.id as user_id, u.nama, u.email,
            COUNT(CASE WHEN a.status = 'Hadir' THEN 1 END) as total_hadir,
            COUNT(CASE WHEN a.status = 'Terlambat' THEN 1 END) as total_terlambat,
            COUNT(CASE WHEN a.status IN ('Izin', 'Sakit', 'Cuti') THEN 1 END) as total_izin
        FROM users u
        LEFT JOIN tb_absensi a ON u.id = a.user_id
        WHERE u.role = 0
        GROUP BY u.id, u.nama, u.email
        ORDER BY total_hadir DESC";

$result = mysqli_query($conn, $sql);
$data = array();
while($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

// 3. 🔥 DETEKSI: Apakah dibuka lewat Browser atau Android?
// Jika ada 'mobile' atau 'Android' di User Agent, kita kasih JSON.
$user_agent = $_SERVER['HTTP_USER_AGENT'];
if (strpos($user_agent, 'Android') !== false || strpos($user_agent, 'okhttp') !== false) {
    header("Content-Type: application/json; charset=UTF-8");
    echo json_encode($data);
    exit();
}

// 4. JIKA DIBUKA DI BROWSER (LAPTOP/HP), TAMPILKAN TABEL MEWAH
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Monitor Absensi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f4f7f6; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .container { margin-top: 50px; }
        .card { border: none; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        .header-box { background: linear-gradient(135deg, #1976D2, #64B5F6); color: white; padding: 30px; border-radius: 15px 15px 0 0; text-align: center; }
        .table thead { background-color: #eeeeee; }
        .badge-hadir { background-color: #2e7d32; }
        .badge-telat { background-color: #c62828; }
        .badge-izin { background-color: #1976d2; }
    </style>
</head>
<body>

<div class="container">
    <div class="card">
        <div class="header-box">
            <h2 class="fw-bold">REKAPITULASI ABSENSI MAHASISWA</h2>
            <p class="mb-0">Universitas Pelita Bangsa - Cloud System</p>
        </div>
        <div class="card-body p-4">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th class="text-center">No</th>
                            <th>Nama Mahasiswa</th>
                            <th>Email</th>
                            <th class="text-center">Hadir</th>
                            <th class="text-center">Terlambat</th>
                            <th class="text-center">Izin/Sakit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; foreach($data as $row): ?>
                        <tr>
                            <td class="text-center fw-bold"><?php echo $no++; ?></td>
                            <td class="fw-bold"><?php echo $row['nama']; ?></td>
                            <td class="text-muted"><?php echo $row['email']; ?></td>
                            <td class="text-center"><span class="badge badge-hadir p-2 px-3"><?php echo $row['total_hadir']; ?></span></td>
                            <td class="text-center"><span class="badge badge-telat p-2 px-3"><?php echo $row['total_terlambat']; ?></span></td>
                            <td class="text-center"><span class="badge badge-izin p-2 px-3"><?php echo $row['total_izin']; ?></span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="text-center mt-3 text-muted">
                <small>Data diperbarui secara realtime dari aplikasi Android</small>
            </div>
        </div>
    </div>
</div>

</body>
</html>