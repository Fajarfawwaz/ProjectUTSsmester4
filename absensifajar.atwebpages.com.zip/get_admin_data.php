<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// 1. Koneksi ke Database AwardSpace
$host = "fdb1034.awardspace.net";
$user = "4757531_absensi";
$pass = "Fajar221!";
$db   = "4757531_absensi";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    echo json_encode(["status" => "error", "message" => "Koneksi Gagal"]);
    exit();
}

// 2. Ambil ID User dari Android (Method POST)
$user_id = isset($_POST['user_id']) ? $_POST['user_id'] : '';

if (empty($user_id)) {
    echo json_encode(["status" => "error", "message" => "ID User tidak dikirim"]);
    exit();
}

// 3. Query ambil data user berdasarkan ID
$sql = "SELECT id, nama, email, role, no_telp, alamat, tgl_lahir FROM users WHERE id = '$user_id'";
$result = mysqli_query($conn, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    // Kirim data user dalam format JSON
    echo json_encode($row);
} else {
    echo json_encode(["status" => "error", "message" => "User tidak ditemukan"]);
}

mysqli_close($conn);
?>